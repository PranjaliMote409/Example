package com.cg.ExamplePom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationBeans {

	@FindBy(how = How.NAME, name = "userName")
	private WebElement username;

	@FindBy(how = How.NAME, name = "userPwd")
	private WebElement password;

	@FindBy(how = How.CLASS_NAME, className = "btn")
	private WebElement login;

	public void onclickLogin() {
		login.click();
	}

	public String getUsername() {
		return username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);

	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);

	}

}
