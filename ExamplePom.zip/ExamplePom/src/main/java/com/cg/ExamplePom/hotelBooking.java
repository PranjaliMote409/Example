package com.cg.ExamplePom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class hotelBooking {

	@FindBy(how = How.ID, id = "txtFirstName")
	private WebElement firstName;

	@FindBy(how = How.ID, id = "txtLastName")
	private WebElement lastName;

	@FindBy(how = How.ID, id = "txtEmail")
	private WebElement email;

	@FindBy(how = How.ID, id = "txtPhone")
	private WebElement phone;

	@FindBy(how = How.NAME, name = "txtAdd")
	private WebElement address;

	@FindBy(how = How.NAME, name = "city")
	private WebElement city;

	@FindBy(how = How.NAME, name = "state")
	private WebElement state;

	@FindBy(how = How.NAME, name = "persons")
	private WebElement persons;

	@FindBy(how = How.ID, id = "txtCardholderName")
	private WebElement cardholderName;

	@FindBy(how = How.ID, id = "txtDebit")
	private WebElement debit;

	@FindBy(how = How.ID, id = "txtCvv")
	private WebElement cvv;

	@FindBy(how = How.ID, id = "txtMonth")
	private WebElement month;

	@FindBy(how = How.ID, id = "txtYear")
	private WebElement year;

	@FindBy(how = How.ID, id = "btnPayment")
	private WebElement payment;

	public void clickConfirmBooking() {
		payment.click();
	}

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getPhone() {
		return phone.getAttribute("value");
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}

	public String getAddress() {
		return address.getAttribute("value");
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
		
	}

	public String getCity() {
		return new Select(this.city).getFirstSelectedOption().getText();
	}

	public void setCity(String city) {
		new Select(this.city).selectByVisibleText(city);
	}

	public String getState() {
		return new Select(this.state).getFirstSelectedOption().getText();
	}

	public void setState(String state) {
		new Select(this.state).selectByVisibleText(state);
	}

	public String getPersons() {
		return new Select(this.persons).getFirstSelectedOption().getText();
	}

	public void setPersons(String persons) {
		new Select(this.persons).selectByVisibleText(persons);
	}

	public String getCardholderName() {
		return cardholderName.getAttribute("value");
	}

	public void setCardholderName(String cardholderName) {
		this.cardholderName.sendKeys(cardholderName);
	}

	public String getDebit() {
		return debit.getAttribute("value");
	}

	public void setDebit(String debit) {
		this.debit.sendKeys(debit);
	}

	public String getCvv() {
		return cvv.getAttribute("value");
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
		
	}

	public String getMonth() {
		return month.getAttribute("value");
	}

	public void setMonth(String month) {
		this.month.sendKeys(month);
	}

	public String getYear() {
		return year.getAttribute("value");
	}

	public void setYear(String year) {
		this.year.sendKeys(year);
	}

}
