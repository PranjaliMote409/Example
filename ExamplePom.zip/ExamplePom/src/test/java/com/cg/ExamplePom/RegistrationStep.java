package com.cg.ExamplePom;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStep {

	private WebDriver driver;
	private RegistrationBeans loginBean;
	private hotelBooking hotelBean;
	DriverUtil util = new DriverUtil();

	@Before
	public void Initialization() {

		driver = util.initiateDriver("chrome");
		driver.manage().window().maximize();
		loginBean = new RegistrationBeans();
		hotelBean = new hotelBooking();
		PageFactory.initElements(driver, loginBean);
		PageFactory.initElements(driver, hotelBean);
	}

	@After
	public void tearDownAfterClass() throws Exception {
		Thread.sleep(1000);
		driver.quit();
	}

	@Test
	public void test() throws Throwable {
		user_is_on_login_page();
		user_login_with_username_and_password();
		go_to_hotel_booking_page();
		user_add_all_details();
		hotel_book_successfully();
	}

	@Given("^user is on login page$")
	public void user_is_on_login_page() throws Throwable {
		driver.get("C:\\Users\\pranj\\Documents\\Selenium\\BDD\\ExamplePom\\webContent\\login.html");

	}

	@When("^user login with username and password$")
	public void user_login_with_username_and_password() throws Throwable {
		loginBean.setUsername("capgemini");
		loginBean.setPassword("capg1234");
		Thread.sleep(5000);
		loginBean.onclickLogin();
		

	}

	@Then("^go to hotel booking page$")
	public void go_to_hotel_booking_page() throws Throwable {
		driver.get("C:\\Users\\pranj\\Documents\\Selenium\\BDD\\ExamplePom\\webContent\\hotelBooking.html");

	}

	@When("^user add all details$")
	public void user_add_all_details() throws Throwable {
		hotelBean.setFirstName("Pranjali");
		hotelBean.setLastName("Mote");
		hotelBean.setEmail("pranjali@gamil.com");
		hotelBean.setPhone("9822561340");
		hotelBean.setAddress("Nagpur Indranagar");
		hotelBean.setCity("Pune");
		hotelBean.setState("Maharashtra");
		hotelBean.setPersons("2");
		hotelBean.setCardholderName("Pranjali");
		hotelBean.setDebit("123645781236");
		hotelBean.setCvv("040");
		hotelBean.setMonth("06");
		hotelBean.setYear("23");

		Thread.sleep(2000);

	}

	@Then("^hotel book successfully$")
	public void hotel_book_successfully() throws Throwable {
		hotelBean.clickConfirmBooking();
		Thread.sleep(1000);
	}

}
